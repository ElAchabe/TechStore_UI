import { useState, useMemo, useEffect } from "react";
import { motion } from "motion/react";
import { ShoppingCart } from "lucide-react";
import { HeroSection } from "./components/HeroSection";
import { WhyTechStore } from "./components/WhyTechStore";
import { StickyCart } from "./components/StickyCart";
import { CartDrawer } from "./components/CartDrawer";
import { ProductDetailPage } from "./components/ProductDetailPage";
import { StorePage } from "./components/StorePage";
import { PersonaSlider } from "./components/PersonaSlider";
import { Product } from "./components/ProductCard";
import { productsData, personaProducts } from "./data/products";

type Page = "home" | "store" | "productDetail";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [cart, setCart] = useState<Array<{ product: Product; quantity: number }>>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isScrolling, setIsScrolling] = useState(false);
  const [storeCategory, setStoreCategory] = useState<"all" | "Laptops" | "Keyboards" | "Monitors" | "Accessories" | "Audio">("all");

  // Calculate cart totals
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  // Handle add to cart
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existingItem = prev.find((item) => item.product.id === product.id);
      if (existingItem) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prev, { product, quantity: 1 }];
      }
    });
  };

  // Handle add to cart with quantity (for product detail page)
  const handleAddToCartWithQuantity = (product: Product, quantity: number) => {
    setCart((prev) => {
      const existingItem = prev.find((item) => item.product.id === product.id);
      if (existingItem) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        return [...prev, { product, quantity }];
      }
    });
  };

  // Handle product click
  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setCurrentPage("productDetail");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle back to products
  const handleBackToProducts = () => {
    setSelectedProduct(null);
    setCurrentPage("store");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle navigate to store
  const handleNavigateToStore = (category?: "all" | "Laptops" | "Keyboards" | "Monitors" | "Accessories" | "Audio") => {
    setStoreCategory(category || "all");
    setCurrentPage("store");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle back to home
  const handleBackToHome = () => {
    setCurrentPage("home");
    setSelectedProduct(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle scroll to personas section
  const scrollToPersonasSection = () => {
    // If already on home page, scroll immediately
    if (currentPage === "home") {
      const personasSection = document.getElementById("personas-section");
      if (personasSection) {
        personasSection.scrollIntoView({ behavior: "smooth" });
      }
    } 
    // If on another page, first go to home then scroll
    else {
      setCurrentPage("home");
      // Wait for the home page to load before scrolling
      setTimeout(() => {
        const personasSection = document.getElementById("personas-section");
        if (personasSection) {
          personasSection.scrollIntoView({ behavior: "smooth" });
        }
      }, 100);
    }
  };

  // Handle update quantity
  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId
          ? { ...item, quantity: newQuantity }
          : item
      )
    );
  };

  // Handle remove from cart
  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Handle clear cart
  const handleClearCart = () => {
    setCart([]);
  };

  // Handle open cart
  const handleOpenCart = () => {
    setIsCartOpen(true);
  };

  // Convert cart to flat list for CartDrawer
  const cartItems = cart.flatMap((item) =>
    Array(item.quantity).fill(item.product)
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Bar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <button
              onClick={handleBackToHome}
              className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-[#0056b3] to-[#003d82] rounded-lg flex items-center justify-center">
                <span className="text-white text-sm">TS</span>
              </div>
              <span className="text-xl text-[#2C3E50]">TechStore</span>
            </button>

            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => handleNavigateToStore("all")}
                className="text-[#2C3E50] hover:text-[#0056b3] transition-colors"
              >
                All Products
              </button>
              <button
                onClick={() => handleNavigateToStore("Laptops")}
                className="text-[#2C3E50] hover:text-[#0056b3] transition-colors"
              >
                Laptops
              </button>
              <button
                onClick={() => handleNavigateToStore("Keyboards")}
                className="text-[#2C3E50] hover:text-[#0056b3] transition-colors"
              >
                Keyboards
              </button>
              <button
                onClick={() => handleNavigateToStore("Accessories")}
                className="text-[#2C3E50] hover:text-[#0056b3] transition-colors"
              >
                Accessories
              </button>

              <button
                onClick={() => handleNavigateToStore("Audio")}
                className="text-[#2C3E50] hover:text-[#0056b3] transition-colors"
              >
                Audio
              </button>

              <button
                onClick={() => handleNavigateToStore("Monitors")}
                className="text-[#2C3E50] hover:text-[#0056b3] transition-colors"
              >
                Monitors
              </button>
              
            </div>

            {/* Shopping Cart */}
            <button
              onClick={handleOpenCart}
              className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ShoppingCart className="w-6 h-6 text-[#2C3E50]" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#0056b3] text-white text-xs rounded-full flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Render based on current page */}
      {currentPage === "productDetail" && selectedProduct ? (
        <ProductDetailPage
          product={selectedProduct}
          onBack={handleBackToProducts}
          onAddToCart={handleAddToCartWithQuantity}
          relatedProducts={[]}
          persona="student"
          onProductClick={handleProductClick}
        />
      ) : currentPage === "store" ? (
        <StorePage
          allProducts={productsData}
          onAddToCart={handleAddToCart}
          onProductClick={handleProductClick}
          onBackToHome={handleBackToHome}
          cartCount={cartItemCount}
          onCartClick={handleOpenCart}
          initialCategory={storeCategory}
        />
      ) : (
        <>
          {/* Hero Section */}
          <HeroSection onExploreClick={handleNavigateToStore} onLearnMore={scrollToPersonasSection} />

          {/* Personas Slider Section */}
          <section id="personas-section" className="py-12 bg-white">
            <PersonaSlider onExploreClick={handleNavigateToStore} />
          </section>

          {/* Why TechStore Section */}
          <WhyTechStore />

          {/* Footer */}
          <footer className="bg-[#2C3E50] text-white py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {/* Brand */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-gradient-to-br from-[#0056b3] to-[#003d82] rounded-lg flex items-center justify-center">
                      <span className="text-white font-semibold">TS</span>
                    </div>
                    <span className="text-xl">TechStore</span>
                  </div>
                  <p className="text-sm text-gray-400 leading-relaxed">
                    Votre partenaire tech premium au Maroc. Design minimaliste, qualité maximale.
                  </p>
                </div>

                {/* Links */}
                <div>
                  <h4 className="mb-4">Produits</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li className="hover:text-white cursor-pointer transition-colors">Ordinateurs</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Smartphones</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Audio</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Accessoires</li>
                  </ul>
                </div>

                <div>
                  <h4 className="mb-4">Support</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li className="hover:text-white cursor-pointer transition-colors">Contact</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Garantie</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Livraison</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Retours</li>
                  </ul>
                </div>

                <div>
                  <h4 className="mb-4">Légal</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li className="hover:text-white cursor-pointer transition-colors">CGV</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Confidentialité</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Cookies</li>
                  </ul>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t border-gray-700 text-center text-sm text-gray-400">
                <p>© 2026 TechStore. Design minimaliste pour le marché marocain.</p>
              </div>
            </div>
          </footer>
        </>
      )}

      {/* Sticky Cart (Mobile) */}
      <StickyCart 
        itemCount={cartItemCount}
        totalPrice={cartTotal}
        onViewCart={handleOpenCart}
      />

      {/* Cart Drawer */}
      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onUpdateQuantity={handleUpdateQuantity}
      />
    </div>
  );
}